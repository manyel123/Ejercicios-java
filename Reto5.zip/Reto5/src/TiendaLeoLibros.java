
import view.MainWindow;

/**
 *
 * @author PC
 */
public class TiendaLeoLibros {
    
    // Nueva ventana principal
    public static void main(String[] args) {
        new MainWindow();
    }
}
